## 微服务CI/CD实践课程文档


- Jira安装部署
- GitLab安装部署
- SonarQube安装部署
- K8s安装部署
